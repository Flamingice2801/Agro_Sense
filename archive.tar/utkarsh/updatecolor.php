<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$color=$_GET['color'];


//echo $query="UPDATE main SET 'active_color'='$color' WHERE 'id'=1";
$query ="UPDATE `main` SET `active_color`='$color' WHERE `id`='1'";
$con = mysqli_connect("localhost","root","toor","utkarsh");


echo $con->query($query);

?>
