<?php

$con = mysqli_connect("localhost","root","toor","utkarsh");

$query="SELECT * FROM `main` WHERE `id`=1";

$result=$con->query($query);

$result=mysqli_fetch_assoc($result);

echo $result['active_color'];
